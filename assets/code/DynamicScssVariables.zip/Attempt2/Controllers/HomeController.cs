﻿using System;
using System.IO;
using System.Linq;
using System.Web.Mvc;

namespace Attempt2.Controllers
{
    public class HomeController : Controller
    {
        private const string BaseScssDirectory = "~/content/scss/";
        private const string OutputDirectory = "clients/";
        private const string MainScssFilename = "main.scss";
        private const string OutputFilenameFormat = "client-{0}.scss";
        
        public ActionResult Index(int? clientId)
        {
            int useClientId = clientId.GetValueOrDefault(1);
            Session["ClientId"] = useClientId;

            if (!ClientScssExists(useClientId))
            {
                SaveClientScssFile(useClientId);
            }


            return View();
        }

        bool ClientScssExists(int clientId)
        {
            string filename = string.Format(OutputFilenameFormat, clientId);
            string path = Server.MapPath(String.Format("{0}{1}{2}", BaseScssDirectory, OutputDirectory, filename));
            return System.IO.File.Exists(path);
        }

        private string GenerateClientScss(int clientId)
        {
            string mainCss = GetMainScss();
            string themeCss = GenerateThemeScss(clientId);

            return string.Format("{0}{1}{2}", themeCss, string.Concat(Enumerable.Repeat(Environment.NewLine, 5)), mainCss);
        }

        private string GenerateThemeScss(int clientId)
        {
            switch (clientId)
            {
                case 1:
                    return @"$PrimaryColour: red;";
                case 2:
                    return @"$PrimaryColour: green;";
                case 3:
                    return @"$PrimaryColour: blue;";
                default:
                    return @"$PrimaryColour: black;";
            }
        }

        private string GetMainScss()
        {
            string filePath = string.Format("{0}{1}", BaseScssDirectory, MainScssFilename);
            return System.IO.File.ReadAllText(Server.MapPath(filePath));
        }

        private void SaveClientScssFile(int clientId)
        {
            string filename = string.Format(OutputFilenameFormat, clientId);
            string filePath = string.Format("{0}{1}{2}", BaseScssDirectory, OutputDirectory, filename);
            filePath = Server.MapPath(filePath);

            string clientScss = GenerateClientScss(clientId);

            using (var writer = new StreamWriter(filePath, false))
            {
                writer.WriteLine(clientScss);
            }

        }


    }
}
